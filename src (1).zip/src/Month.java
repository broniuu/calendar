public class Month {
    private int numberOfDays;
    private int number;
    private String name;

    Month(int numberOfDays, int number, String name){

    }

    public void setNumberOfDays(int numberOfDays) {
        this.numberOfDays = numberOfDays;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setName(String name) {
        this.name = name;
    }
}
